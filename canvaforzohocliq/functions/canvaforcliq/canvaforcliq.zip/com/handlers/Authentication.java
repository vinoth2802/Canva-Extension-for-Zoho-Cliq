package com.handlers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.zc.cliq.enums.FORM_FIELD_TEXT_FORMAT;
import com.zc.cliq.enums.FORM_FIELD_TYPE;
import com.zc.cliq.objects.CommandSuggestion;
import com.zc.cliq.objects.Form;
import com.zc.cliq.objects.FormActionsObject;
import com.zc.cliq.objects.FormInput;
import com.zc.cliq.objects.FormValue;
import com.zc.cliq.requests.CommandHandlerRequest;
import com.zc.cliq.util.ZCCliqUtil;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import java.security.SecureRandom;
import java.util.Base64;
import java.security.MessageDigest;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import com.zc.component.object.ZCObject;
import com.zc.component.object.ZCTable;
import com.zc.component.object.ZCRowObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import com.zc.component.zcql.ZCQL;


public class Authentication {
    public static boolean isAuthorized(String zohoUserId) throws  Exception {
        String query = String.format("SELECT * FROM authentication WHERE zoho_user_id = '%s'", zohoUserId);
        ArrayList<ZCRowObject> rowList = ZCQL.getInstance().executeQuery(query);
        return rowList.isEmpty();
    }
    public static  Map<String, Object> sendAuthorizeMessage(String url) throws Exception {
        String authorizeMessage = """
        {
          "text": "To use the Canva extension, you need to authorize it. Click the button below to proceed.",
          "bot": {
            "name": "Canva",
            "image": "https://res.cloudinary.com/dui2rawnc/image/upload/v1733575829/canva_logo_fjbk24.jpg"
          },
          "card": {
            "title": "Canva Extension Authorization",
            "theme": "modern-inline"
          },
          "buttons": [
            {
              "label": "Authorize",
              "hint": "",
              "type": "+",
              "action": {
                "type": "open.url",
                "data": {
                  "web": "%s"
                }
              }
            }
          ]
        }
        """.formatted(url);
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> response = objectMapper.readValue(authorizeMessage,new TypeReference<Map<String, Object>>() {});
        return response;
    }
//    public static String authenticate(String zohoUserId) {
//        CatalystDatastore datastore = CatalystDatastore.getInstance();
//        String accessToken = new String();
//        try {
//            Table table = datastore.getTable("authentication");
//            Row userRow = table.getRow(zohoUserId);
//
//            if (userRow == null) {
//                authorize(zohoUserId);
//            }
//
//            Date tokenExpiryDate = (Date) userRow.get("token_expiry");
//            if (tokenExpiryDate != null) {
//                Date currentDate = new Date();
//
//                if (currentDate.before(tokenExpiryDate)) {
//
//                }
//            }
//        }
//        catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
    public static Map<String, Object> authorize(String zohoUserId) throws Exception{
        String clientId = "OC-AZNfBUmU3kqZ";// System.getenv("client_id"); ;
        String clientSecret = "cnvcaLwMbd4-xMi1pBXFwMLLrozj7J_GawSi9Nu049g-1BAka1ea17b1";
        String scope = "design:meta:read design:content:read";
        String encodedScope = URLEncoder.encode(scope, StandardCharsets.UTF_8.toString());

        String codeVerifier = generateCodeVerifier();
        String codeChallenge = generateCodeChallenge(codeVerifier);

        String authorizationUrl = "https://www.canva.com/api/oauth/authorize"
                + "?response_type=code"
                + "&client_id=" + clientId
                + "&scope=" + encodedScope
                + "&code_challenge=" + codeChallenge
                + "&code_challenge_method=S256";
        return Authentication.sendAuthorizeMessage(authorizationUrl);
    }
    private static String generateCodeVerifier() throws Exception{
        byte[] randomBytes = new byte[64];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(randomBytes);

        return Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes)
                .replace('+', '-').replace('/', '_');
    }

    private static String generateCodeChallenge(String codeVerifier)  throws Exception{
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(codeVerifier.getBytes("UTF-8"));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(hash)
                .replace('+', '-').replace('/', '_');
    }

}